#pragma once

#include"utility\OthelloLogicException.h"
#include"utility\Utility.h"
