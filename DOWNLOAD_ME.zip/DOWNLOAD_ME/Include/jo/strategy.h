#pragma once

#include"strategy\Strategy.h"
