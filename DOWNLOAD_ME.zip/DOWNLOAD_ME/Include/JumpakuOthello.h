#pragma once

#pragma comment(lib, "JumpakuOthello.lib")

#include"jo/othello.h"
#include"jo/strategy.h"
#include"jo/utility.h"
