var searchData=
[
  ['back',['back',['../da/daf/classjo_1_1_history.html#a4093a993c86f7dd702920b0155ac8fba',1,'jo::History']]],
  ['begin',['begin',['../d3/dda/classjo_1_1_board_frame.html#aa2d4f32d18658cb89452ad514c851bf1',1,'jo::BoardFrame::begin()'],['../d3/dda/classjo_1_1_board_frame.html#aa47a77cfa16ad9bf42dbf9f015b796d5',1,'jo::BoardFrame::begin() const '],['../db/d68/classjo_1_1_square_collection.html#a2a3786cf2ab19a10719b237c17dd22c9',1,'jo::SquareCollection::begin()'],['../db/d68/classjo_1_1_square_collection.html#ac36c54f14c81b97e55d1cbc8a237c923',1,'jo::SquareCollection::begin() const ']]],
  ['board',['Board',['../de/d77/classjo_1_1_board.html',1,'jo']]],
  ['board',['board',['../de/d1d/classjo_1_1_othello.html#a8bcbe4e6b39aa06ccde496c0a58cfc33',1,'jo::Othello::board()'],['../de/d77/classjo_1_1_board.html#a9ee491d4fea680cf69b033374a9fdfcb',1,'jo::Board::Board()']]],
  ['board_2ecpp',['Board.cpp',['../dc/d34/_board_8cpp.html',1,'']]],
  ['board_2eh',['Board.h',['../de/ded/_board_8h.html',1,'']]],
  ['board_5fm',['board_m',['../d3/dda/classjo_1_1_board_frame.html#add15f1ec60aa84b9e7176d2587f8e40a',1,'jo::BoardFrame::board_m()'],['../d5/d1e/classjo_1_1_board_iterator.html#afbfbf226f56aecccee34dbade62defe0',1,'jo::BoardIterator::board_m()']]],
  ['boardframe',['BoardFrame',['../d3/dda/classjo_1_1_board_frame.html',1,'jo']]],
  ['boardframe_2eh',['BoardFrame.h',['../d8/d07/_board_frame_8h.html',1,'']]],
  ['boardframe_3c_20square_20_3e',['BoardFrame&lt; Square &gt;',['../d3/dda/classjo_1_1_board_frame.html',1,'jo']]],
  ['boarditerator',['BoardIterator',['../d5/d1e/classjo_1_1_board_iterator.html',1,'jo']]],
  ['boarditerator',['BoardIterator',['../d5/d1e/classjo_1_1_board_iterator.html#aab361a26193e9f0544c07bcab6980633',1,'jo::BoardIterator::BoardIterator(Frame_t *board, Pos pos)'],['../d5/d1e/classjo_1_1_board_iterator.html#abdf33db48119b1725cd75931c3c06e1d',1,'jo::BoardIterator::BoardIterator()=default'],['../d5/d1e/classjo_1_1_board_iterator.html#af831451c02c59d5c9264f14006ab2932',1,'jo::BoardIterator::BoardIterator(BoardIterator const &amp;)=default'],['../d5/d1e/classjo_1_1_board_iterator.html#a572f63aa51588c4a4a7c8524c27e9fdb',1,'jo::BoardIterator::BoardIterator(BoardIterator &amp;&amp;)=default']]],
  ['boarditerator_2eh',['BoardIterator.h',['../df/d6c/_board_iterator_8h.html',1,'']]],
  ['boardmanager',['BoardManager',['../df/dc1/classjo_1_1_board_manager.html',1,'jo']]],
  ['boardmanager_2ecpp',['BoardManager.cpp',['../de/d99/_board_manager_8cpp.html',1,'']]],
  ['boardmanager_2eh',['BoardManager.h',['../df/d3c/_board_manager_8h.html',1,'']]]
];
