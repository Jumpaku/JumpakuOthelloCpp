var searchData=
[
  ['dark',['dark',['../de/d61/classjo_1_1_color.html#a652f102b7bf9152f9a0146baa993c76d',1,'jo::Color']]],
  ['disc',['disc',['../dd/d16/classjo_1_1_square.html#a77c77cf61fbdb17ec9156cc78da7d16e',1,'jo::Square::disc()'],['../de/d28/classjo_1_1_disc.html#af57bc6c29742f10c2f53fea3a1aaf683',1,'jo::Disc::Disc()'],['../de/d28/classjo_1_1_disc.html#ad3d807a39a721db74e863742902802db',1,'jo::Disc::Disc(Color const &amp;color)']]],
  ['disccount',['discCount',['../de/d1d/classjo_1_1_othello.html#a07462c22f2b67d5156c4cc4ad749e46b',1,'jo::Othello']]]
];
