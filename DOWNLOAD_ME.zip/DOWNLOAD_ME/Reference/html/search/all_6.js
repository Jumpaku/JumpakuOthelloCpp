var searchData=
[
  ['getavailables',['getAvailables',['../de/d1d/classjo_1_1_othello.html#a1925d8d97a182759c78dd501900ceab4',1,'jo::Othello::getAvailables()'],['../df/dc1/classjo_1_1_board_manager.html#a53ec31243716f1b31e93c86ba03e6315',1,'jo::BoardManager::getAvailables(Color const &amp;color) const '],['../df/dc1/classjo_1_1_board_manager.html#af86e9476c404b4cd611d57a366cb804d',1,'jo::BoardManager::getAvailables(Board const &amp;board, Color const &amp;color)']]],
  ['getboard',['getBoard',['../df/dc1/classjo_1_1_board_manager.html#a06a219175c2f0a34cf84bab062e6ac3d',1,'jo::BoardManager']]],
  ['getreversibles',['getReversibles',['../de/d1d/classjo_1_1_othello.html#a6e3af208ecd7967c6ddde02e194c2131',1,'jo::Othello::getReversibles()'],['../df/dc1/classjo_1_1_board_manager.html#a7e39284b068fb77f6d9ab13b09285948',1,'jo::BoardManager::getReversibles(Square const &amp;choice) const '],['../df/dc1/classjo_1_1_board_manager.html#a00c07d85fead6958934a97cf271a7d77',1,'jo::BoardManager::getReversibles(Board const &amp;board, Square const &amp;choice)']]]
];
