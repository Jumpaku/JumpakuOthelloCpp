var searchData=
[
  ['next',['next',['../d5/d1e/classjo_1_1_board_iterator.html#a1b9de401d5a2d8d54b9da6b2eb1c4494',1,'jo::BoardIterator']]]
];
