var searchData=
[
  ['result_5fm',['result_m',['../d1/dff/classothello_1_1_strategy.html#a606880dc83458d210a689aba805ff505',1,'othello::Strategy']]]
];
