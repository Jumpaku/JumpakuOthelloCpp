var searchData=
[
  ['dark',['dark',['../de/d61/classjo_1_1_color.html#a652f102b7bf9152f9a0146baa993c76d',1,'jo::Color::dark()'],['../de/d61/classjo_1_1_color.html#afe6cb6280e37cd83d28daebe07bb41c7aacaef50d33fc86532c260a045c672f3e',1,'jo::Color::DARK()']]],
  ['dir',['Dir',['../d5/d4a/namespacejo.html#a6f792e6dae065f2dff0893b2e8400685',1,'jo']]],
  ['dir_2ecpp',['Dir.cpp',['../d7/d13/_dir_8cpp.html',1,'']]],
  ['dir_2eh',['Dir.h',['../d7/d84/_dir_8h.html',1,'']]],
  ['disc',['Disc',['../de/d28/classjo_1_1_disc.html',1,'jo']]],
  ['disc',['disc',['../dd/d16/classjo_1_1_square.html#a77c77cf61fbdb17ec9156cc78da7d16e',1,'jo::Square::disc()'],['../de/d28/classjo_1_1_disc.html#af57bc6c29742f10c2f53fea3a1aaf683',1,'jo::Disc::Disc()'],['../de/d28/classjo_1_1_disc.html#ad3d807a39a721db74e863742902802db',1,'jo::Disc::Disc(Color const &amp;color)']]],
  ['disc_2ecpp',['Disc.cpp',['../db/df2/_disc_8cpp.html',1,'']]],
  ['disc_2eh',['Disc.h',['../dd/d17/_disc_8h.html',1,'']]],
  ['disccount',['discCount',['../de/d1d/classjo_1_1_othello.html#a07462c22f2b67d5156c4cc4ad749e46b',1,'jo::Othello']]]
];
