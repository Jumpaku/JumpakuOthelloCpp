var searchData=
[
  ['hasfinished',['hasFinished',['../de/d1d/classjo_1_1_othello.html#a4d95c433e485ce0b10ef9a616aca8003',1,'jo::Othello']]],
  ['history',['history',['../de/d1d/classjo_1_1_othello.html#ad125f1d568fce460ce8218c4dd4f177e',1,'jo::Othello']]]
];
