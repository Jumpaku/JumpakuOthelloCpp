var searchData=
[
  ['turndata',['TurnData',['../d7/d74/classothello_1_1_turn_data.html',1,'othello']]]
];
