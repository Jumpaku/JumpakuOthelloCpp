var searchData=
[
  ['hasfinished',['hasFinished',['../de/d1d/classjo_1_1_othello.html#a4d95c433e485ce0b10ef9a616aca8003',1,'jo::Othello']]],
  ['history',['history',['../de/d1d/classjo_1_1_othello.html#ad125f1d568fce460ce8218c4dd4f177e',1,'jo::Othello']]],
  ['history',['History',['../da/daf/classjo_1_1_history.html',1,'jo']]],
  ['history_2ecpp',['History.cpp',['../d0/dfa/_history_8cpp.html',1,'']]],
  ['history_2eh',['History.h',['../d0/de8/_history_8h.html',1,'']]]
];
