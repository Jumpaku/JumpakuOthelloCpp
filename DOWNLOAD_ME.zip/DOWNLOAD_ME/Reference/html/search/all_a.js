var searchData=
[
  ['light',['LIGHT',['../de/d61/classjo_1_1_color.html#afe6cb6280e37cd83d28daebe07bb41c7af8589806bbf66241917092b2a6e18c6f',1,'jo::Color::LIGHT()'],['../de/d61/classjo_1_1_color.html#a1ced780844d487e0950616879804e4d0',1,'jo::Color::light()']]]
];
