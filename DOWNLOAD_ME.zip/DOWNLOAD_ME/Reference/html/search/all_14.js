var searchData=
[
  ['‾boardframe',['‾BoardFrame',['../d3/dda/classjo_1_1_board_frame.html#a7d96bb8c11ceeb841d68ec10c2e4ed34',1,'jo::BoardFrame']]],
  ['‾othellologicexception',['‾OthelloLogicException',['../d3/d4e/classjo_1_1_othello_logic_exception.html#a90b5672d623ded7ae4f5c64fa41446a7',1,'jo::OthelloLogicException']]],
  ['‾strategy',['‾Strategy',['../d5/db6/classjo_1_1_strategy.html#a10524a2d0575a31917ebc72d3ccc060f',1,'jo::Strategy']]]
];
