var indexSectionsWithContent =
{
  0: "abcdefghijlmnoprstuw‾",
  1: "bcdhopst",
  2: "j",
  3: "bcdhmopst",
  4: "bcdeghijlmnoprstu‾",
  5: "bip",
  6: "acfis",
  7: "d",
  8: "delnsw",
  9: "j"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "files",
  4: "functions",
  5: "variables",
  6: "typedefs",
  7: "enums",
  8: "enumvalues",
  9: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Files",
  4: "Functions",
  5: "Variables",
  6: "Typedefs",
  7: "Enumerations",
  8: "Enumerator",
  9: "Pages"
};

