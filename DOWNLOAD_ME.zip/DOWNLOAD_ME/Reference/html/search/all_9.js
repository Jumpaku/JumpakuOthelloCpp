var searchData=
[
  ['jumpaku_20othello_20main_20page',['Jumpaku Othello Main Page',['../index.html',1,'']]],
  ['j',['j',['../dd/d16/classjo_1_1_square.html#a7abe10736abd3f9489ab237ab4824592',1,'jo::Square::j()'],['../d6/d58/classjo_1_1_pos.html#ac2ed06e9c7b8b75dea42c8f2d9dd4dfb',1,'jo::Pos::j() const '],['../d6/d58/classjo_1_1_pos.html#a79188d7f74f6585a91b7aa5eff519d44',1,'jo::Pos::j(int j)'],['../d4/db4/classjo_1_1_turn_data.html#a144dd39f8ffc179788ea61b5709391f1',1,'jo::TurnData::j()']]],
  ['jo',['jo',['../d5/d4a/namespacejo.html',1,'']]]
];
