var searchData=
[
  ['isend_5fm',['isEnd_m',['../d5/d1e/classjo_1_1_board_iterator.html#a6b90cca6e3c70573020bbad7a83f314b',1,'jo::BoardIterator']]]
];
