var searchData=
[
  ['light',['light',['../de/d61/classjo_1_1_color.html#a1ced780844d487e0950616879804e4d0',1,'jo::Color']]]
];
