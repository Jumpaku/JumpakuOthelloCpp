var searchData=
[
  ['constiterator_5ft',['ConstIterator_t',['../d3/dda/classjo_1_1_board_frame.html#a4f68426b5b021ac4c802827cf7ef79c1',1,'jo::BoardFrame::ConstIterator_t()'],['../db/d68/classjo_1_1_square_collection.html#aa59d3161a00313249652c2cc30e82e6c',1,'jo::SquareCollection::ConstIterator_t()']]]
];
