var searchData=
[
  ['undo',['undo',['../de/d1d/classjo_1_1_othello.html#a42813145f9d1ff861d4bda98b8f7eb02',1,'jo::Othello']]],
  ['unput',['unput',['../dd/d16/classjo_1_1_square.html#a43489e636bc1a51a74cd034b0c456512',1,'jo::Square']]]
];
