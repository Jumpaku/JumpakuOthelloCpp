var searchData=
[
  ['playturn',['playTurn',['../de/d1d/classjo_1_1_othello.html#a3dcb871957b440506747eba8f1830a58',1,'jo::Othello::playTurn(Square const &amp;choice)'],['../de/d1d/classjo_1_1_othello.html#a5874f9433998761ab923ba13ad501c0d',1,'jo::Othello::playTurn(Strategy_p strategy)']]],
  ['popback',['popBack',['../da/daf/classjo_1_1_history.html#a480071f823984935e0c3966682ae564b',1,'jo::History']]],
  ['popfront',['popFront',['../da/daf/classjo_1_1_history.html#a781ec2cef75e5bfc6023e256f6783d90',1,'jo::History']]],
  ['pos',['Pos',['../d6/d58/classjo_1_1_pos.html',1,'jo']]],
  ['pos',['Pos',['../d6/d58/classjo_1_1_pos.html#a9447b622eba9887453389a6aff5738cd',1,'jo::Pos::Pos()=default'],['../d6/d58/classjo_1_1_pos.html#a2d4ae81bcd248514afd2f0d709bd6cb2',1,'jo::Pos::Pos(int i, int j)'],['../dd/d16/classjo_1_1_square.html#a2dba6551747f86b546fb5be3cced8522',1,'jo::Square::pos()'],['../d4/db4/classjo_1_1_turn_data.html#a188557864336f53adcbd062be39255f5',1,'jo::TurnData::pos()']]],
  ['pos_2ecpp',['Pos.cpp',['../d7/d64/_pos_8cpp.html',1,'']]],
  ['pos_2eh',['Pos.h',['../d4/d46/_pos_8h.html',1,'']]],
  ['pos_5fm',['pos_m',['../d5/d1e/classjo_1_1_board_iterator.html#a8b5a4d93ded83291063b4b171f1a9a32',1,'jo::BoardIterator']]],
  ['pushback',['pushBack',['../da/daf/classjo_1_1_history.html#a2a4dc9fb8f79da94da96218b264695cf',1,'jo::History::pushBack()'],['../db/d68/classjo_1_1_square_collection.html#a3aa8910dd1894fb308bfe642b90485e9',1,'jo::SquareCollection::pushBack()']]],
  ['put',['put',['../dd/d16/classjo_1_1_square.html#a0a244cdc21b43c373738dea1c4113912',1,'jo::Square::put()'],['../df/dc1/classjo_1_1_board_manager.html#a188c3b8796b5c026bf498962caddffd2',1,'jo::BoardManager::put(Square const &amp;choice)'],['../df/dc1/classjo_1_1_board_manager.html#a395fb4102278c3339d937b9829780421',1,'jo::BoardManager::put(Board &amp;board, Square const &amp;choice)']]]
];
