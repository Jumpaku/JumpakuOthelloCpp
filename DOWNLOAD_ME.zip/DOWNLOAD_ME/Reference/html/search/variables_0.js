var searchData=
[
  ['board_5fm',['board_m',['../d3/dda/classjo_1_1_board_frame.html#add15f1ec60aa84b9e7176d2587f8e40a',1,'jo::BoardFrame::board_m()'],['../d5/d1e/classjo_1_1_board_iterator.html#afbfbf226f56aecccee34dbade62defe0',1,'jo::BoardIterator::board_m()']]]
];
