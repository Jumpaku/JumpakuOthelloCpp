var searchData=
[
  ['iterator_5ft',['Iterator_t',['../d3/dda/classjo_1_1_board_frame.html#ab234d5a5b98d1d7bc204d32e423b12ba',1,'jo::BoardFrame::Iterator_t()'],['../db/d68/classjo_1_1_square_collection.html#abfd3f4cbee34e7645ddd075918aac602',1,'jo::SquareCollection::Iterator_t()']]]
];
