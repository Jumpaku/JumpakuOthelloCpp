var searchData=
[
  ['othello_2ecpp',['Othello.cpp',['../dc/df2/_othello_8cpp.html',1,'']]],
  ['othello_2eh',['Othello.h',['../d8/d2c/_othello_8h.html',1,'']]],
  ['othellologicexception_2ecpp',['OthelloLogicException.cpp',['../de/d84/_othello_logic_exception_8cpp.html',1,'']]],
  ['othellologicexception_2eh',['OthelloLogicException.h',['../d2/d04/_othello_logic_exception_8h.html',1,'']]]
];
