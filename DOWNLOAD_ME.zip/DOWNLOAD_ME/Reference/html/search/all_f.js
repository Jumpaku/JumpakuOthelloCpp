var searchData=
[
  ['restart',['restart',['../de/d1d/classjo_1_1_othello.html#adf3c9c50d570e0f338fdc107f28d1dc9',1,'jo::Othello']]],
  ['reverse',['reverse',['../de/d28/classjo_1_1_disc.html#afe7dbc62da90bcf18a6353a59a8aec07',1,'jo::Disc::reverse()'],['../dd/d16/classjo_1_1_square.html#a9c5018848f724da6ea246040840e4b90',1,'jo::Square::reverse()'],['../df/dc1/classjo_1_1_board_manager.html#adbaa6aebe6f919dbeb16cf2a01bb263f',1,'jo::BoardManager::reverse(SquareCollection const &amp;reversibles)'],['../df/dc1/classjo_1_1_board_manager.html#a0ccec8b23770a5acbc5309195ac1b99a',1,'jo::BoardManager::reverse(Board &amp;board, SquareCollection const &amp;reversibles)']]],
  ['reversed',['reversed',['../de/d61/classjo_1_1_color.html#a0757737d6f7e2207f6cf9fefea2d4515',1,'jo::Color']]]
];
