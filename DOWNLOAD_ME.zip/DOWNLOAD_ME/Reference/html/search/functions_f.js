var searchData=
[
  ['think',['think',['../d5/db6/classjo_1_1_strategy.html#aecf0bb798fa5dfdbd1294a8f7601e9c9',1,'jo::Strategy']]],
  ['tostring',['toString',['../de/d61/classjo_1_1_color.html#a3eaa8d0a88861c413fe36bf8ee89e4ba',1,'jo::Color']]],
  ['turncolor',['turnColor',['../de/d1d/classjo_1_1_othello.html#a130d99d732afa8943f287a15cb9a2e80',1,'jo::Othello']]],
  ['turncount',['turnCount',['../de/d1d/classjo_1_1_othello.html#a15523b34635f2b9e5b09782ae789115f',1,'jo::Othello']]],
  ['turndata',['TurnData',['../d4/db4/classjo_1_1_turn_data.html#a734a3e6efd3c816893c3629ef7fa0dcc',1,'jo::TurnData::TurnData()=default'],['../d4/db4/classjo_1_1_turn_data.html#aa17c1d4d5aa4c1d8d82a034fbb2d1189',1,'jo::TurnData::TurnData(int const &amp;count, Pos const &amp;pos, Color const &amp;color)']]]
];
