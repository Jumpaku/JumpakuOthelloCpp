var searchData=
[
  ['jumpaku_20othello_20main_20page',['Jumpaku Othello Main Page',['../index.html',1,'']]]
];
