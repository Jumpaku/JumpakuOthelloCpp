var searchData=
[
  ['color',['Color',['../de/d61/classjo_1_1_color.html',1,'jo']]],
  ['constboarditerator',['ConstBoardIterator',['../d4/df3/classjo_1_1_const_board_iterator.html',1,'jo']]]
];
