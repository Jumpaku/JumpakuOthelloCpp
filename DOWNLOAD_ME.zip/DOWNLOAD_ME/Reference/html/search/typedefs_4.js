var searchData=
[
  ['strategy_5fp',['Strategy_p',['../d5/d4a/namespacejo.html#acf0cc6d43c6e2f733c34addeda513be3',1,'jo']]]
];
