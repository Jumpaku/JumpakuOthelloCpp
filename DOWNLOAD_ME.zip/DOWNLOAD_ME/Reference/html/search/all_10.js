var searchData=
[
  ['s',['S',['../d5/d4a/namespacejo.html#a6f792e6dae065f2dff0893b2e8400685a5dbc98dcc983a70728bd082d1a47546e',1,'jo']]],
  ['se',['SE',['../d5/d4a/namespacejo.html#a6f792e6dae065f2dff0893b2e8400685af003c44deab679aa2edfaff864c77402',1,'jo']]],
  ['setboard',['setBoard',['../df/dc1/classjo_1_1_board_manager.html#a01480cf9bbcdc5b62dca01c9cf9f5714',1,'jo::BoardManager']]],
  ['size',['size',['../da/daf/classjo_1_1_history.html#a0a0cd5fed7f2ee242854ecc4e8d57e70',1,'jo::History::size()'],['../db/d68/classjo_1_1_square_collection.html#aadbf477e8cfbefdd9361891a4029b87f',1,'jo::SquareCollection::size()']]],
  ['square',['Square',['../dd/d16/classjo_1_1_square.html',1,'jo']]],
  ['square',['Square',['../dd/d16/classjo_1_1_square.html#a67a6915416b813f8e47e5a0ef69d56b3',1,'jo::Square::Square()=default'],['../dd/d16/classjo_1_1_square.html#a812e459d7ddf45dac7bf92f3e9bfd00e',1,'jo::Square::Square(Pos const &amp;pos)'],['../dd/d16/classjo_1_1_square.html#a08d34886b029f9a4ad19934c0743b69d',1,'jo::Square::Square(int const &amp;i, int const &amp;j)'],['../dd/d16/classjo_1_1_square.html#ab42bf8221aff9a1387cf72e5cf60b734',1,'jo::Square::Square(Pos const &amp;pos, Color const &amp;color)'],['../dd/d16/classjo_1_1_square.html#a6ca3a1ec8711e6cbf98f91dc402ed1a9',1,'jo::Square::Square(int const &amp;i, int const &amp;j, Color const &amp;color)'],['../dd/d16/classjo_1_1_square.html#a6c82051ff1c78e9563420245ed4c90da',1,'jo::Square::Square(Square const &amp;square)'],['../dd/d16/classjo_1_1_square.html#a261d1f14e61751588a7163fdf51fb569',1,'jo::Square::Square(Square &amp;&amp;)=default']]],
  ['square_2ecpp',['Square.cpp',['../da/dbe/_square_8cpp.html',1,'']]],
  ['square_2eh',['Square.h',['../d8/d87/_square_8h.html',1,'']]],
  ['squarecollection',['SquareCollection',['../db/d68/classjo_1_1_square_collection.html',1,'jo']]],
  ['squarecollection_2ecpp',['SquareCollection.cpp',['../d4/d98/_square_collection_8cpp.html',1,'']]],
  ['squarecollection_2eh',['SquareCollection.h',['../de/d9e/_square_collection_8h.html',1,'']]],
  ['strategy',['Strategy',['../d5/db6/classjo_1_1_strategy.html',1,'jo']]],
  ['strategy_2eh',['Strategy.h',['../dd/db4/_strategy_8h.html',1,'']]],
  ['strategy_5fp',['Strategy_p',['../d5/d4a/namespacejo.html#acf0cc6d43c6e2f733c34addeda513be3',1,'jo']]],
  ['sw',['SW',['../d5/d4a/namespacejo.html#a6f792e6dae065f2dff0893b2e8400685a6f56aa4e2561eb66f17f6d8de8070a77',1,'jo']]]
];
