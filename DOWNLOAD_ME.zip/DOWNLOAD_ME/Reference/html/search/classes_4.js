var searchData=
[
  ['othello',['Othello',['../de/d1d/classjo_1_1_othello.html',1,'jo']]],
  ['othellologicexception',['OthelloLogicException',['../d3/d4e/classjo_1_1_othello_logic_exception.html',1,'jo']]]
];
