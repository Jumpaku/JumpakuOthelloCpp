var searchData=
[
  ['strategy_5fp',['Strategy_p',['../dd/d8d/namespaceothello.html#aa916497effcb984eb10a3c1ae0f541c0',1,'othello']]]
];
