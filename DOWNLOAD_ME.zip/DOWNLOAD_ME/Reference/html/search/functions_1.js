var searchData=
[
  ['canput',['canPut',['../df/dc1/classjo_1_1_board_manager.html#a4271b3c4e2d230ec31d27fd519de7ada',1,'jo::BoardManager::canPut(Square const &amp;choice) const '],['../df/dc1/classjo_1_1_board_manager.html#a4e91f08aa9285de4ba11a7fcadf4edf3',1,'jo::BoardManager::canPut(Color const &amp;color) const '],['../df/dc1/classjo_1_1_board_manager.html#ad6f68fc0cb9550247156a4be2626be94',1,'jo::BoardManager::canPut(Board const &amp;board, Square const &amp;choice)'],['../df/dc1/classjo_1_1_board_manager.html#a0a1bc33ff838c38c298bafb93748c41b',1,'jo::BoardManager::canPut(Board const &amp;board, Color const &amp;color)']]],
  ['choice',['choice',['../d4/db4/classjo_1_1_turn_data.html#a509a371342ce996f53298922ede65f6f',1,'jo::TurnData']]],
  ['clear',['clear',['../da/daf/classjo_1_1_history.html#a8ef13fdf00ec0786268fd6bd211bf38f',1,'jo::History']]],
  ['color',['Color',['../de/d61/classjo_1_1_color.html#ab13717d6c76fb564e3b0815aa327e786',1,'jo::Color::Color()'],['../de/d28/classjo_1_1_disc.html#ab746d6285c68359bcb2ad899cfb29f7e',1,'jo::Disc::color()'],['../d4/db4/classjo_1_1_turn_data.html#a825da2660db7fccceb0f45d9c7744801',1,'jo::TurnData::color()']]],
  ['constboarditerator',['ConstBoardIterator',['../d4/df3/classjo_1_1_const_board_iterator.html#aaf7985c2067dd49a7e30e423de7c0d05',1,'jo::ConstBoardIterator']]],
  ['count',['count',['../d4/db4/classjo_1_1_turn_data.html#ad4c163e7fbd5cb02d41b16f602af237b',1,'jo::TurnData']]]
];
