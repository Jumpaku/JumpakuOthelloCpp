var searchData=
[
  ['i',['i',['../dd/d16/classjo_1_1_square.html#aadf912421e8f4448f4c778210d0d291f',1,'jo::Square::i()'],['../d6/d58/classjo_1_1_pos.html#afc7c09b0cba441f4ac30a3eb986aa59f',1,'jo::Pos::i() const '],['../d6/d58/classjo_1_1_pos.html#ab94d831aa421bc7966b6a795b9964168',1,'jo::Pos::i(int i)'],['../d4/db4/classjo_1_1_turn_data.html#ae6c8417e035718dc3dd1fe6be8c0f484',1,'jo::TurnData::i()']]],
  ['isavailable',['isAvailable',['../de/d1d/classjo_1_1_othello.html#ac71192137881cc4ff5316fef4e1c6e8a',1,'jo::Othello']]],
  ['iterator',['iterator',['../d3/dda/classjo_1_1_board_frame.html#a289a3b6d44e943b9fdb22430fb505d8e',1,'jo::BoardFrame::iterator(Pos const &amp;pos)'],['../d3/dda/classjo_1_1_board_frame.html#a49be8b890b100754096b04db8814f92a',1,'jo::BoardFrame::iterator(int const &amp;i, int const &amp;j)'],['../d3/dda/classjo_1_1_board_frame.html#a20feb2e9a78d1a8788dddccac97a72bb',1,'jo::BoardFrame::iterator(Pos const &amp;pos) const '],['../d3/dda/classjo_1_1_board_frame.html#a4beb12fefc30e6818119c7771fc9735a',1,'jo::BoardFrame::iterator(int const &amp;i, int const &amp;j) const ']]]
];
